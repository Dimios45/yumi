# tinyumi D405 + T265, no Quest

Open `assembly/tinyumi_D405_T265_NO_QUEST_assembly.stl` to view the placed
mechanism. It is not a one-piece print. `assembly/…preview.glb` shows part
colors. Neither camera housing nor cables are included; the D405 holder and
T265 bolt-on adapter are included.

Print from `print_parts/` individually. Filenames give quantity for repeated
parts: 2 jaw adapters, 2 finger holders, 2 L brackets, 1 pinion, and one each
of the other parts. The fingertips are prototypes; use your original tips if
preferred. Optional rail stops: 2 A and 2 B. Rails, bearings, screws, inserts,
camera bodies and straps are purchased hardware, not in the ZIP.

Important: The T265 adapter is a separate plate. Keep your existing D405 holder.
Its mounting screws must be 5 mm longer with the same washer stack, preserving
thread engagement. Follow `instructions/T265_bolt_on_README.md` and check screw
protrusion before tightening.

This is a CAD fit prototype. The source assembly simplifies some components;
check real camera/cable/hand clearance and slice each printed part separately.
`assembly/manifest.json` records included components and the holder placement.
