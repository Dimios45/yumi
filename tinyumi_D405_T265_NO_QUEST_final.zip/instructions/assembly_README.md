# tinyumi assembly: D405 + separate T265 adapter, no Quest

**`tinyumi_D405_T265_NO_QUEST_assembly.stl`** is the complete mechanical
assembly in millimetres. It combines the gripper reference geometry, the
rail-stop-pocket base **without Quest pad**, the user's centred-hole D405 holder
and clamp, and the separate bolt-on T265 adapter. The matching colored
`tinyumi_D405_T265_NO_QUEST_preview.glb` is in metres.

This assembled STL is for viewing, checking pose, and sharing the arrangement.
**Do not slice it as one print:** moving mechanisms and mating faces overlap in
assembled space, and the reference gripper scene has simplified rails,
carriages, tips and screw heads. Neither actual camera housing nor its cable is
included. The optional rail stops and hand straps are also omitted.

For printing, use the individual solids:

- [No-Quest base](../../hardware/rail_stops/plate_v6_with_rail_stops.stl)
- [Existing D405 holder](../d405_centered_holes/D405_UMI_bracket.stl) and
  [clamp](../d405_centered_holes/D405_UMI_clamp.stl)
- [Separate T265 adapter](../../hardware/realsense_t265/bolt_on/T265_bolt_on_PRINT_THIS.stl)
- Existing gripper parts from `hardware/STL/` and fingertips from
  `bambu/full_rebuild/` as appropriate for your build.

The D405 holder was positioned by aligning its lower 40 mm hole pair to the
base's 40.5708 mm pair, leaving 0.2854 mm nominal offset per screw. The
existing 3.4 mm clearance holes accommodate this on paper. This placement is
CAD-derived, not measured on the assembled print. Verify camera, hand and cable
clearance on the real gripper before operation.

`manifest.json` lists the 21 included components, exact transform and limits.
Rebuild with the command at the top of `build.py`.
