# Separate T265 adapter — print only this part

Use **`T265_bolt_on_PRINT_THIS.stl`**. This is a standalone 64 x 62 x 5 mm plate
that attaches behind the upper panel of your already-printed, centred-hole D405
holder. The matching STEP is exact editable CAD. Keep the existing holder and
clamp; neither needs reprinting or drilling.

The lower M3 clearance pair has 20 mm spacing, matching the existing upper D405
holes. The upper pair has 50 mm spacing for the T265. All four bores are 3.4 mm.
The upper pair sits 40 mm above the lower pair along the plate.

## Assembly

1. Support/remove the D405 as needed to access its two upper mounting screws.
2. Seat the adapter flat against the **back** of the sloped holder panel, with
   the wide end above the holder. Line up the adapter's lower pair with the
   existing 20 mm pair.
3. Replace the two shared holder screws with screws **5 mm longer under the
   head**, keeping the same washer stack and original thread engagement.
   If adding washers, add their thickness to the required screw length too.
   For example, an existing 8 mm screw becomes 13 mm with the same washers;
   a 14 mm screw plus an additional 1 mm washer gives the same protrusion.
   Measure rather than choosing the next longer screw without compensation.
   When these screws thread into the D405, do not exceed its 4 mm insertion
   limit. Re-seat the D405 in its original position and tighten both screws.
4. Attach the T265 to the upper pair, on the forward face of the adapter, with
   **two M3x8 socket-head screws and 0.5 mm washers**. Through the 5 mm pad this
   gives 2.5 mm nominal camera insertion. **T265 maximum insertion is 3 mm**;
   measure actual protrusion before tightening.
5. Check the real camera bodies, both USB plugs, hand clearance and views.
   Secure cables with slack so they do not pull on the adapter.

The existing upper screws must be accessible and replaceable for this shared
screw arrangement. No screw thread is cut into the printed adapter itself.

## Printing and checks

Print the supplied STL flat: PETG, 0.2 mm layers, five walls and 35% infill are
starting settings. No supports are required by this flat geometry. Check the
holes and mating surface after printing. The optional `D405_20mm_interface_gauge`
checks hole spacing and the added 5 mm screw stack before the full print.

Validated: single CAD solid, watertight STL, source-hole alignment within
0.001 mm, unobstructed modelled screw-head/driver corridors, and no meaningful
overlap with the existing bracket, clamp or nominal T265 body (residual mesh
boolean noise below 0.001 mm³). Source holder files are unchanged.

Physical fit, stiffness under motion, actual mounted D405 housing, cables and
full-gripper clearance are untested. `bolt_on_preview.png` and
`bolt_on_assembly_preview.glb` show the separate adapter on the existing holder.
The grey camera is a nominal housing envelope, not supplier CAD.

This bolt-on adapter supersedes the earlier integrated/reprint design in the
parent directory. Do not use the earlier combined-bracket files for this task.

## Sources and rebuild

Holder: `output/d405_centered_holes/D405_UMI_bracket.stl`. Camera dimensions:
Intel T265 datasheet 572522-004, Table 3-13 and Figure 6-8 (pages 17 and 28):
https://www.realsenseai.com/wp-content/uploads/2019/09/Intel_RealSense_Tracking_Camera_Datasheet_Rev004_release.pdf

Run from the repository root:

```sh
uv run --python 3.12 --with cadquery --with trimesh --with matplotlib --with manifold3d python hardware/realsense_t265/bolt_on/build.py
uv run --python 3.12 --with trimesh --with matplotlib python hardware/realsense_t265/bolt_on/render_preview.py
```
